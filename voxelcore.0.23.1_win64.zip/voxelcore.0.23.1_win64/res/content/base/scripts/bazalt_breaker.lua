function on_block_break_by(x, y, z, p)
    block.set(x, y, z, 0, 0)
end
